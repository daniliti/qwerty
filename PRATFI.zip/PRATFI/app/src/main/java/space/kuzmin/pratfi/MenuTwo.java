package space.kuzmin.pratfi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;

public class MenuTwo extends AppCompatActivity {
  private final int ID_Home = 1;
  private final int ID_CAMERA = 2;
  private final int ID_NOTIFICATION = 3;
  private final int ID_ACCOUNT = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_two);

      TextView selected_page = findViewById(R.id.selected_page);
      MeowBottomNavigation bottomNavigation = findViewById(R.id.bottomNavigation);

      bottomNavigation.add(new MeowBottomNavigation.Model(ID_Home,R.drawable.ic_baseline_home_24));
      bottomNavigation.add(new MeowBottomNavigation.Model(ID_CAMERA,R.drawable.ic_baseline_camera_alt_24));
      bottomNavigation.add(new MeowBottomNavigation.Model(ID_NOTIFICATION,R.drawable.ic_baseline_notifications_24));
      bottomNavigation.add(new MeowBottomNavigation.Model(ID_ACCOUNT,R.drawable.ic_baseline_account_circle_24));

      bottomNavigation.setOnClickMenuListener(new MeowBottomNavigation.ClickListener() {
        @Override
        public void onClickItem(MeowBottomNavigation.Model item) {
          Toast.makeText(MenuTwo.this, "clicked item : " + item.getId(), Toast.LENGTH_SHORT).show();
        }
      });

      bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener() {
        @Override
        public void onShowItem(MeowBottomNavigation.Model item) {

          String name;
          switch (item.getId()){
            case ID_Home: name = "Home";
              break;

            case ID_CAMERA: name = "Camera";
              Intent i = new Intent(MenuTwo.this,MainActivity.class);
              startActivity(i);
              break;

            case ID_NOTIFICATION: name = "Notification";
              break;

            case ID_ACCOUNT: name = "Account";
              break;

            default: name = "";
          }

        }
      });

      bottomNavigation.setCount(ID_NOTIFICATION, "4");
      bottomNavigation.show(ID_Home, true);

    }
}
