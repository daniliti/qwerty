package space.kuzmin.pratfi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.ramotion.circlemenu.CircleMenuView;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        final CircleMenuView circleMenu = findViewById(R.id.circleMenu);

        circleMenu.setEventListener(new CircleMenuView.EventListener(){
          @Override
          public void onMenuOpenAnimationStart(@NonNull CircleMenuView view) {
            //do something
          }

          @Override
          public void onButtonClickAnimationStart(@NonNull CircleMenuView view, int buttonIndex) {
            super.onButtonClickAnimationStart(view, buttonIndex);

            switch (buttonIndex) {

              case 0:
                Toast.makeText(Menu.this,"Home Button Clicked!", Toast.LENGTH_SHORT).show();
                break;

              case 1:
                Toast.makeText(Menu.this, "Location Button Clicked", Toast.LENGTH_SHORT).show();


                break;

              case 2:
                Toast.makeText(Menu.this, "Search Button Clicked", Toast.LENGTH_SHORT).show();
                break;

              case 3:
                Toast.makeText(Menu.this, "Camera Button Clicked", Toast.LENGTH_SHORT).show();

                break;

              case 4:
                Toast.makeText(Menu.this, "Setting Button Clicked", Toast.LENGTH_SHORT).show();

            }
          }
        });

    }
}
